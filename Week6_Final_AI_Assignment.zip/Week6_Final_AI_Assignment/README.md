# Student Performance Prediction Using Machine Learning

## Project overview
A regression project that estimates a student's final examination marks from study habits, attendance, previous performance, assignment score, sleep duration and selected learning-support indicators.

**Model:** Random Forest Regressor  
**Target:** `final_exam_marks` (0–100)  
**Dataset:** 500 synthetic illustrative student records (the raw file contains 503 rows because 3 duplicates were deliberately added; missing values were also introduced for cleaning practice).

> **Important dataset note:** This project uses a reproducible synthetic dataset generated for this assignment. It is not real student data and must not be used to make actual educational decisions. The dataset is included so the notebook runs offline and the cleaning workflow is demonstrable.

## Folder structure
- `dataset/` raw and cleaned CSV files
- `notebooks/` complete Jupyter notebook
- `src/` scripts to train and run an example prediction
- `models/` saved fitted model and feature-column metadata
- `visualizations/` EDA and model-result charts
- `reports/` test predictions and final PDF report
- `requirements.txt` Python dependencies

## Setup
Python 3.10+ is recommended.

```bash
python -m venv .venv
# Windows:
.venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate

pip install -r requirements.txt
```

## Run
From the project root:

```bash
python src/train_model.py
python src/predict_student.py
jupyter notebook notebooks/Student_Performance_Prediction.ipynb
```

The notebook contains all steps from data loading and cleaning through EDA, model training, prediction and evaluation.

## Evaluation
The saved report and notebook contain the metrics calculated on a held-out 20% test set. A mean-prediction baseline is also reported for context. Results can vary if the dataset or random seed is changed.

## Responsible use and limitations
- Synthetic records do not represent real students or causal relationships.
- A prediction is an estimate, not a judgement of ability or potential.
- Real deployment would require consent, privacy safeguards, representative real-world data, bias testing, human oversight and ongoing monitoring.
- Correlation and feature importance do not prove causation.
