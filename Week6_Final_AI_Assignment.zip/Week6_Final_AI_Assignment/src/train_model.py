"""
Student Performance Prediction
Run: python src/train_model.py
Dataset is illustrative synthetic data bundled with this project.
"""
from pathlib import Path
import math
import joblib
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.dummy import DummyRegressor

ROOT = Path(__file__).resolve().parents[1]
data = pd.read_csv(ROOT / "dataset" / "student_performance_raw.csv")
data = data.drop_duplicates()
for col in data.select_dtypes(include=np.number).columns:
    data[col] = data[col].fillna(data[col].median())
for col in data.select_dtypes(include="object").columns:
    data[col] = data[col].fillna(data[col].mode()[0])
data.to_csv(ROOT / "dataset" / "student_performance_cleaned.csv", index=False)

X = data.drop(columns=["final_exam_marks"])
y = data["final_exam_marks"]
X = pd.get_dummies(X, columns=["internet_access", "extracurricular_participation"], drop_first=True, dtype=int)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
model = RandomForestRegressor(n_estimators=300, min_samples_split=4, min_samples_leaf=2, random_state=42)
model.fit(X_train, y_train)
pred = model.predict(X_test)
mse = mean_squared_error(y_test, pred)
print(f"MAE : {mean_absolute_error(y_test, pred):.3f}")
print(f"MSE : {mse:.3f}")
print(f"RMSE: {math.sqrt(mse):.3f}")
print(f"R2  : {r2_score(y_test, pred):.3f}")
baseline = DummyRegressor(strategy="mean").fit(X_train, y_train)
print(f"Baseline MAE: {mean_absolute_error(y_test, baseline.predict(X_test)):.3f}")
joblib.dump({"model": model, "feature_columns": list(X.columns)}, ROOT / "models" / "student_performance_random_forest.joblib")

# Example prediction using one held-out row
sample = X_test.iloc[[0]]
print("Example predicted mark:", round(float(model.predict(sample)[0]), 1))
