"""Predict marks for one student using the saved model."""
from pathlib import Path
import joblib
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
bundle = joblib.load(ROOT / "models" / "student_performance_random_forest.joblib")
model, columns = bundle["model"], bundle["feature_columns"]

student = pd.DataFrame([{
    "study_hours_per_day": 4.0,
    "attendance_percentage": 85.0,
    "previous_exam_score": 70.0,
    "assignment_score": 78.0,
    "sleep_hours_per_day": 7.0,
    "internet_access": "Yes",
    "extracurricular_participation": "No"
}])
student = pd.get_dummies(student, columns=["internet_access", "extracurricular_participation"], drop_first=True, dtype=int)
student = student.reindex(columns=columns, fill_value=0)
print("Predicted final exam marks:", round(float(model.predict(student)[0]), 1), "/ 100")
